const welcomePage = document.getElementById('welcomePage');
const signUpButton = document.getElementById('signUpButton');
const checkAppointmentsButton = document.getElementById('checkAppointmentsButton');
const tutoringForm = document.getElementById('tutoringForm');
const confirmationPage = document.getElementById('confirmationPage');
const appointmentDetails = document.getElementById('appointmentDetails');
const goBackButton = document.getElementById('goBackButton');
const appointmentsPage = document.getElementById('appointmentsPage');
const appointmentsList = document.getElementById('appointmentsList');
const backToWelcomeButton = document.getElementById('backToWelcomeButton');
const contactNumber = "(720)5527351";
let scheduledAppointments = [];

signUpButton.addEventListener('click', function() {
  welcomePage.style.display = 'none';
  tutoringForm.style.display = 'block';
});

checkAppointmentsButton.addEventListener('click', function() {
  welcomePage.style.display = 'none';
  appointmentsPage.style.display = 'block';
  displayAppointments();
});

tutoringForm.addEventListener('submit', function(event) {
  event.preventDefault();

  const name = document.getElementById('name').value;
  const grade = document.getElementById('grade').value;
  const subject = document.getElementById('subject').value;
  const date = document.getElementById('date').value;
  const time = document.getElementById('time').value;

  const appointment = { name, grade, subject, date, time };
  scheduledAppointments.push(appointment);

  appointmentDetails.innerHTML = `
    <strong>Name:</strong> ${name}<br>
    <strong>Grade:</strong> ${grade}<br>
    <strong>Subject:</strong> ${subject}<br>
    <strong>Date:</strong> ${date}<br>
    <strong>Time:</strong> ${time}<br>
    <strong>Please contact:</strong> ${contactNumber} to arrange a location.
  `;

  tutoringForm.style.display = 'none';
  confirmationPage.style.display = 'block';
});

goBackButton.addEventListener('click', function() {
  tutoringForm.reset();
  confirmationPage.style.display = 'none';
  welcomePage.style.display = 'block';
});

backToWelcomeButton.addEventListener('click', function() {
  appointmentsPage.style.display = 'none';
  welcomePage.style.display = 'block';
});

function displayAppointments() {
  appointmentsList.innerHTML = '';
  scheduledAppointments.forEach(appointment => {
    const appointmentItem = document.createElement('div');
    appointmentItem.classList.add('appointment-item');
    appointmentItem.innerHTML = `
      <strong>Name:</strong> ${appointment.name}<br>
      <strong>Grade:</strong> ${appointment.grade}<br>
      <strong>Subject:</strong> ${appointment.subject}<br>
      <strong>Date:</strong> ${appointment.date}<br>
      <strong>Time:</strong> ${appointment.time}
    `;
    appointmentsList.appendChild(appointmentItem);
  });
}
 
